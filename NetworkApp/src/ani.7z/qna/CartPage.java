package ani.qna;

import java.awt.Color;

public class CartPage extends Page {
	public CartPage(AppMain appMain) {
		super(appMain);
		this.setBackground(Color.GREEN);
	}
}
