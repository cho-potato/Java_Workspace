package ani.qna;

import java.awt.Color;

public class ProductPage extends Page {
	public ProductPage(AppMain appMain) {
		super(appMain);
		this.setBackground(Color.BLACK);
	}
}
