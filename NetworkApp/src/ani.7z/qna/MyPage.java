package ani.qna;

import java.awt.Color;

public class MyPage extends Page {
	public MyPage(AppMain appMain) {
		super(appMain);
		this.setBackground(Color.RED);
	}
}
