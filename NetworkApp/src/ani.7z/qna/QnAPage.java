package ani.qna;

import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

public class QnAPage extends Page {
	JPanel p_list; // row 패널들이 붙여질 영역
	JPanel p_num; // 페이지 번호가 붙여질 영역
	JButton bt_regist; // 글등록 버튼
	
	ArrayList<Row>rows = new ArrayList<Row>(); // size 0
	
//	페이징 처리란? 데이터를 분할하여 출력하는 기법 (산수계산에 의함)
//	페이징 처리 로직을 개발하는 과정에서 DB연동은 필수가 아니다
	int totalRecord = 6; // 총 레코드 수 
	
	public QnAPage(AppMain appMain) {
		super(appMain);
//		this.setBackground(Color.LIGHT_GRAY);
		p_list = new JPanel();
		p_num = new JPanel();
		bt_regist = new JButton("글등록");
		
		p_list.setPreferredSize(new Dimension(770, 455));
		p_num.setPreferredSize(new Dimension(770, 50));
		
		p_list.setBackground(Color.WHITE);
		p_num.setBackground(Color.WHITE);
		
		add(bt_regist);
		add(p_list);
		add(p_num);
		
		createRow();
	}
	
//	row 생성하기
	public void createRow() {
//		rows = new Row[10];
		for (int i = 0; i<10; i++) {
			ReBoard dto = new ReBoard(); // 임시적으로 DTO 넘기기
			dto.setTitle("진호형");
			dto.setWriter("진호형");
			dto.setRegdate("2022-12-25");
			dto.setHit(45);
			
			Row row = new Row(i, dto, this);
			rows.add(row); // 리스트에 추가
			p_list.add(row); // 패널에 부착
			
		}
		this.updateUI(); // 현재 패널 갱신
	}
//	row에 대한 하이라이트 효과
	public void showLight(int n) {
//		모든 rows를 대상으로
		for(int i = 0; i<rows.size(); i++) {
			Row row = rows.get(i); // 리스트에서 요소 하나 꺼내기
			if (i==n) {
				row.setBackground(Color.RED); // 배경색 주기
			} else {
				row.setBackground(Color.WHITE); // 돌려놓기
			}
		}
	}
}
